package com.codigofacilito.ejemplos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemplosApplicationTests {

	@Test
	void contextLoads() {
	}

}
